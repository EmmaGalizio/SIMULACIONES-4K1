package emma.galzio.simulacionestp7consultorio.controller.utils;

public class ConstantesGenerador {
    public static final String LINEAL = "GENERADOR_LINEAL";
    public static final String MULTIPLICATIVO = "GENERADOR_MULTIPLICATIVO";
    public static final String LENGUAJE = "GENERADOR_LENGUAJE";
}
