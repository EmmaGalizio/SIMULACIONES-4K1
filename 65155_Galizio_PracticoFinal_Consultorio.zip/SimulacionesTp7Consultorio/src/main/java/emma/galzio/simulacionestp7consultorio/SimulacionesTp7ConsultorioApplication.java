package emma.galzio.simulacionestp7consultorio;

import javafx.application.Application;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimulacionesTp7ConsultorioApplication {

    public static void main(String[] args) {
        Application.launch(Tp7SimulacionesFxApplication.class,args);
    }

}
