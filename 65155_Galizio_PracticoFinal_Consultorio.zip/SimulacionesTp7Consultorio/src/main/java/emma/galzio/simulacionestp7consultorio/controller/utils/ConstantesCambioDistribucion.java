package emma.galzio.simulacionestp7consultorio.controller.utils;

public class ConstantesCambioDistribucion {
    public static final String UNIFORME = "UNIFORME";
    public static final String EXP = "EXPONENCIAL";
    public static final String EXP_NEG = "EXPONENCIAL_NEGATIVA";
    public static final String NORMAL_BOXMULLER = "NORMAL_BOXMULLER";
    public static final String NORMAL_CONVOLUCION = "NORMAL_CONVOLUCION";
    public static final String POISSON = "POISSON";

}
